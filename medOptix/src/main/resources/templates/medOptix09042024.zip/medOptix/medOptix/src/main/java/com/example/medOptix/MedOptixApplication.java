package com.example.medOptix;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MedOptixApplication {

	public static void main(String[] args) {
		SpringApplication.run(MedOptixApplication.class, args);

	}

}
