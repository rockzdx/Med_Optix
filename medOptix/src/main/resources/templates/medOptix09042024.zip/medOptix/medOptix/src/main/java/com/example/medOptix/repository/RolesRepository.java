package com.example.medOptix.repository;

import com.example.medOptix.model.RolesModel;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RolesRepository extends JpaRepository<RolesModel,Long> {

}
