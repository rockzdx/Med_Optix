package com.example.medOptix.service;

public class ClinicRegService {
}
