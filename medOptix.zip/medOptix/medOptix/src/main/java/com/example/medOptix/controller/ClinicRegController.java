package com.example.medOptix.controller;

public class ClinicRegController {
}
