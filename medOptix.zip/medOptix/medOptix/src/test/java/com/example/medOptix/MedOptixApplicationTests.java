package com.example.medOptix;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MedOptixApplicationTests {

	@Test
	void contextLoads() {
	}

}
